<?php

declare(strict_types=1);

namespace KimaiPlugin\KimaiPushBridgeBundle\Controller\Profile;

use App\Controller\AbstractController;
use App\Entity\User;
use App\Repository\TimesheetRepository;
use App\Repository\UserRepository;
use App\Utils\PageSetup;
use KimaiPlugin\KimaiPushBridgeBundle\Form\Model\PushSettingsModel;
use KimaiPlugin\KimaiPushBridgeBundle\Form\PushSettingsType;
use KimaiPlugin\KimaiPushBridgeBundle\Service\PushMessageBuilder;
use KimaiPlugin\KimaiPushBridgeBundle\Service\PushSubscriptionManager;
use Symfony\Bridge\Doctrine\Attribute\MapEntity;
use Symfony\Component\ExpressionLanguage\Expression;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;
use Symfony\Component\Security\Http\Attribute\IsGranted;

#[Route(path: '/profile')]
#[IsGranted(new Expression("is_granted('view_own_profile') or is_granted('view_other_profile')"))]
final class PushSettingsController extends AbstractController
{
    public function __construct(private readonly TimesheetRepository $timesheetRepository)
    {
    }

    #[Route(path: '/{username}/push-bridge', name: 'user_profile_push_bridge', methods: ['GET', 'POST'])]
    #[IsGranted('preferences', 'profile')]
    public function settingsAction(
        #[MapEntity(mapping: ['username' => 'username'])]
        User $profile,
        Request $request,
        UserRepository $userRepository,
        PushSubscriptionManager $pushSubscriptionManager,
        PushMessageBuilder $pushMessageBuilder
    ): Response {
        $model = PushSettingsModel::fromUser($profile, $pushSubscriptionManager);

        $form = $this->createForm(
            PushSettingsType::class,
            $model,
            [
                'action' => $this->generateUrl('user_profile_push_bridge', ['username' => $profile->getUserIdentifier()]),
                'method' => 'POST',
            ]
        );
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            /** @var PushSettingsModel $submitted */
            $submitted = $form->getData();
            $submitted->applyToUser($profile, $pushSubscriptionManager);
            $userRepository->saveUser($profile);

            $this->flashSuccess('action.update.success');

            $locale = $request->getLocale();
            if ($this->getUser()->getId() === $profile->getId()) {
                $locale = $profile->getPreferenceValue('language', $locale, false);
            }

            return $this->redirectToRoute('user_profile_push_bridge', [
                '_locale' => $locale,
                'username' => $profile->getUserIdentifier(),
            ]);
        }

        return $this->render('@KimaiPushBridge/push_bridge/settings.html.twig', [
            'tab' => 'push-bridge',
            'page_setup' => $this->createPageSetup($profile),
            'user' => $profile,
            'form' => $form->createView(),
            'push_enabled' => $pushSubscriptionManager->isPushEnabled($profile),
            'message_definitions' => PushSettingsModel::getMessageFieldDefinitions(),
            'preview_messages' => $pushMessageBuilder->buildPreviews($profile, $this->buildTimerPreviewPlaceholderContext($profile)),
        ]);
    }

    /**
     * @return array<string, string>
     */
    private function buildTimerPreviewPlaceholderContext(User $profile): array
    {
        $latestTimesheet = $this->timesheetRepository->findOneBy(
            ['user' => $profile],
            ['begin' => 'DESC', 'id' => 'DESC']
        );

        if ($latestTimesheet === null) {
            return [];
        }

        $project = $latestTimesheet->getProject();
        $customer = $project?->getCustomer();
        $activity = $latestTimesheet->getActivity();
        $begin = $latestTimesheet->getBegin();

        return [
            'customer' => trim((string) ($customer?->getName() ?? '')),
            'project' => trim((string) ($project?->getName() ?? '')),
            'activity' => trim((string) ($activity?->getName() ?? '')),
            'starttime' => $begin?->format('H:i') ?? '',
        ];
    }

    private function createPageSetup(User $profile): PageSetup
    {
        $page = new PageSetup('kimai_push_bridge.settings.page_title');
        $page->setActionName('user');
        $page->setActionView('settings');
        $page->setActionPayload(['user' => $profile]);

        return $page;
    }
}
