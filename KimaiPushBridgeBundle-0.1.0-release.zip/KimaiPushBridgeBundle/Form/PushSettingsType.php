<?php

declare(strict_types=1);

namespace KimaiPlugin\KimaiPushBridgeBundle\Form;

use App\Form\Type\YesNoType;
use KimaiPlugin\KimaiPushBridgeBundle\Form\Model\PushSettingsModel;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\Length;

final class PushSettingsType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $toggleRowClass = 'mb-3 pb-3 border-bottom';

        $builder
            ->add('timer', YesNoType::class, [
                'label' => 'kimai_push_bridge.preference.timer',
                'help' => 'kimai_push_bridge.preference_help.timer',
                'row_attr' => ['class' => $toggleRowClass],
            ])
            ->add('absenceRequested', YesNoType::class, [
                'label' => 'kimai_push_bridge.preference.absence_requested',
                'help' => 'kimai_push_bridge.preference_help.absence_requested',
                'row_attr' => ['class' => $toggleRowClass],
            ])
            ->add('absenceApproved', YesNoType::class, [
                'label' => 'kimai_push_bridge.preference.absence_approved',
                'help' => 'kimai_push_bridge.preference_help.absence_approved',
                'row_attr' => ['class' => $toggleRowClass],
            ])
            ->add('absenceRejected', YesNoType::class, [
                'label' => 'kimai_push_bridge.preference.absence_rejected',
                'help' => 'kimai_push_bridge.preference_help.absence_rejected',
                'row_attr' => ['class' => $toggleRowClass],
            ])
            ->add('workingTimeApproved', YesNoType::class, [
                'label' => 'kimai_push_bridge.preference.working_time_approved',
                'help' => 'kimai_push_bridge.preference_help.working_time_approved',
                'row_attr' => ['class' => $toggleRowClass],
            ])
            ->add('workingTimeUnlocked', YesNoType::class, [
                'label' => 'kimai_push_bridge.preference.working_time_unlocked',
                'help' => 'kimai_push_bridge.preference_help.working_time_unlocked',
            ]);

        foreach (PushSettingsModel::getMessageFieldDefinitions() as $definition) {
            $builder
                ->add($definition['titleField'], TextType::class, [
                    'label' => 'kimai_push_bridge.settings.message.title_label',
                    'required' => false,
                    'help' => 'kimai_push_bridge.settings.message.title_help',
                    'constraints' => [new Length(['max' => 120])],
                    'attr' => [
                        'maxlength' => 120,
                        'placeholder' => 'Kimai',
                    ],
                ])
                ->add($definition['bodyField'], TextareaType::class, [
                    'label' => 'kimai_push_bridge.settings.message.body_label',
                    'required' => false,
                    'help' => 'kimai_push_bridge.settings.message.body_help',
                    'constraints' => [new Length(['max' => 240])],
                    'attr' => [
                        'maxlength' => 240,
                        'rows' => 4,
                    ],
                ]);
        }
    }

    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults([
            'data_class' => PushSettingsModel::class,
        ]);
    }
}
