<?php

declare(strict_types=1);

namespace KimaiPlugin\KimaiPushBridgeBundle\Form\Model;

use App\Entity\User;
use KimaiPlugin\KimaiPushBridgeBundle\Service\PushSubscriptionManager;

final class PushSettingsModel
{
    public bool $timer = true;
    public bool $absenceRequested = true;
    public bool $absenceApproved = true;
    public bool $absenceRejected = true;
    public bool $workingTimeApproved = true;
    public bool $workingTimeUnlocked = true;
    public ?string $customTitle = null;
    public ?string $customBody = null;
    public ?string $timerStartedTitle = null;
    public ?string $timerStartedBody = null;
    public ?string $timerStoppedTitle = null;
    public ?string $timerStoppedBody = null;
    public ?string $absenceRequestedTitle = null;
    public ?string $absenceRequestedBody = null;
    public ?string $absenceApprovedTitle = null;
    public ?string $absenceApprovedBody = null;
    public ?string $absenceRejectedTitle = null;
    public ?string $absenceRejectedBody = null;
    public ?string $workingTimeApprovedTitle = null;
    public ?string $workingTimeApprovedBody = null;
    public ?string $workingTimeUnlockedTitle = null;
    public ?string $workingTimeUnlockedBody = null;

    /**
     * @return array<int, array{event: string, label: string, titleField: string, bodyField: string}>
     */
    public static function getMessageFieldDefinitions(): array
    {
        return [
            [
                'event' => PushSubscriptionManager::getCustomMessageDefinitions()[0]['event'],
                'label' => PushSubscriptionManager::getCustomMessageDefinitions()[0]['label'],
                'titleField' => 'timerStartedTitle',
                'bodyField' => 'timerStartedBody',
            ],
            [
                'event' => PushSubscriptionManager::getCustomMessageDefinitions()[1]['event'],
                'label' => PushSubscriptionManager::getCustomMessageDefinitions()[1]['label'],
                'titleField' => 'timerStoppedTitle',
                'bodyField' => 'timerStoppedBody',
            ],
            [
                'event' => PushSubscriptionManager::getCustomMessageDefinitions()[2]['event'],
                'label' => PushSubscriptionManager::getCustomMessageDefinitions()[2]['label'],
                'titleField' => 'absenceRequestedTitle',
                'bodyField' => 'absenceRequestedBody',
            ],
            [
                'event' => PushSubscriptionManager::getCustomMessageDefinitions()[3]['event'],
                'label' => PushSubscriptionManager::getCustomMessageDefinitions()[3]['label'],
                'titleField' => 'absenceApprovedTitle',
                'bodyField' => 'absenceApprovedBody',
            ],
            [
                'event' => PushSubscriptionManager::getCustomMessageDefinitions()[4]['event'],
                'label' => PushSubscriptionManager::getCustomMessageDefinitions()[4]['label'],
                'titleField' => 'absenceRejectedTitle',
                'bodyField' => 'absenceRejectedBody',
            ],
            [
                'event' => PushSubscriptionManager::getCustomMessageDefinitions()[5]['event'],
                'label' => PushSubscriptionManager::getCustomMessageDefinitions()[5]['label'],
                'titleField' => 'workingTimeApprovedTitle',
                'bodyField' => 'workingTimeApprovedBody',
            ],
            [
                'event' => PushSubscriptionManager::getCustomMessageDefinitions()[6]['event'],
                'label' => PushSubscriptionManager::getCustomMessageDefinitions()[6]['label'],
                'titleField' => 'workingTimeUnlockedTitle',
                'bodyField' => 'workingTimeUnlockedBody',
            ],
        ];
    }

    public static function fromUser(User $user, PushSubscriptionManager $pushSubscriptionManager): self
    {
        $model = new self();
        $model->timer = (bool) $user->getPreferenceValue(PushSubscriptionManager::PREFERENCE_EVENT_TIMER, true, false);
        $model->absenceRequested = (bool) $user->getPreferenceValue(PushSubscriptionManager::PREFERENCE_EVENT_ABSENCE_REQUESTED, true, false);
        $model->absenceApproved = (bool) $user->getPreferenceValue(PushSubscriptionManager::PREFERENCE_EVENT_ABSENCE_APPROVED, true, false);
        $model->absenceRejected = (bool) $user->getPreferenceValue(PushSubscriptionManager::PREFERENCE_EVENT_ABSENCE_REJECTED, true, false);
        $model->workingTimeApproved = (bool) $user->getPreferenceValue(PushSubscriptionManager::PREFERENCE_EVENT_WORKING_TIME_APPROVED, true, false);
        $model->workingTimeUnlocked = (bool) $user->getPreferenceValue(PushSubscriptionManager::PREFERENCE_EVENT_WORKING_TIME_UNLOCKED, true, false);
        $model->customTitle = $pushSubscriptionManager->getCustomTitle($user);
        $model->customBody = $pushSubscriptionManager->getCustomBody($user);

        foreach (self::getMessageFieldDefinitions() as $definition) {
            $titleField = $definition['titleField'];
            $bodyField = $definition['bodyField'];
            $model->{$titleField} = $pushSubscriptionManager->getCustomTitleForEvent($user, $definition['event']);
            $model->{$bodyField} = $pushSubscriptionManager->getCustomBodyForEvent($user, $definition['event']);
        }

        return $model;
    }

    public function applyToUser(User $user, PushSubscriptionManager $pushSubscriptionManager): void
    {
        $user->setPreferenceValue(PushSubscriptionManager::PREFERENCE_EVENT_TIMER, $this->timer);
        $user->setPreferenceValue(PushSubscriptionManager::PREFERENCE_EVENT_ABSENCE_REQUESTED, $this->absenceRequested);
        $user->setPreferenceValue(PushSubscriptionManager::PREFERENCE_EVENT_ABSENCE_APPROVED, $this->absenceApproved);
        $user->setPreferenceValue(PushSubscriptionManager::PREFERENCE_EVENT_ABSENCE_REJECTED, $this->absenceRejected);
        $user->setPreferenceValue(PushSubscriptionManager::PREFERENCE_EVENT_WORKING_TIME_APPROVED, $this->workingTimeApproved);
        $user->setPreferenceValue(PushSubscriptionManager::PREFERENCE_EVENT_WORKING_TIME_UNLOCKED, $this->workingTimeUnlocked);
        $pushSubscriptionManager->setCustomTitle($user, $this->customTitle);
        $pushSubscriptionManager->setCustomBody($user, $this->customBody);

        foreach (self::getMessageFieldDefinitions() as $definition) {
            $titleField = $definition['titleField'];
            $bodyField = $definition['bodyField'];
            $pushSubscriptionManager->setCustomTitleForEvent($user, $definition['event'], $this->{$titleField});
            $pushSubscriptionManager->setCustomBodyForEvent($user, $definition['event'], $this->{$bodyField});
        }
    }
}
