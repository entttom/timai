<?php

declare(strict_types=1);

namespace KimaiPlugin\KimaiPushBridgeBundle;

use App\Plugin\PluginInterface;
use Symfony\Component\HttpKernel\Bundle\Bundle;

final class KimaiPushBridgeBundle extends Bundle implements PluginInterface
{
    public function getPath(): string
    {
        return __DIR__;
    }
}
