# Kimai Push Bridge Bundle

Dieses Bundle beobachtet relevante Kimai-Events und sendet ein signiertes Minimal-Signal an einen Relay-Server. Der Relay verschickt daraus einen sichtbaren, generischen Push an ein FCM Topic. Weder das Plugin noch der Push enthalten sensible Projektdaten.

Die sichtbaren Push-Texte werden im Plugin in der beim Empfaenger eingestellten Kimai-Sprache erzeugt und als `visible_title` / `visible_body` an den Relay uebergeben. Fuer Sprachvarianten ohne eigene Plugin-Uebersetzung greift ein Fallback auf Englisch.

Wenn ein Event durch die Timai-iOS-App selbst ausgeloest wurde, unterdrueckt das Plugin den Push-Versand vollstaendig. Dafuer muss die App ihre schreibenden Kimai-API-Requests mit `X-Timai-Client: ios` markieren.

`normalized_instance` wird automatisch aus der Kimai-URL abgeleitet. Das Topic-Secret wird beim ersten Zugriff serverseitig erzeugt und unter Kimai `var/data/kimai_push_bridge/topic_secret` gespeichert.

Ob ein User Push überhaupt erhalten soll, wird als User-Preference in Kimai gespeichert. Ohne aktives Opt-in der App wird kein Webhook für diesen User versendet.

## Installationspfad

Das Bundle gehört in die Kimai-Installation unter:

```text
var/plugins/KimaiPushBridgeBundle/
```

Wenn du dieses Repository direkt nutzt, kopiere den Ordner `var/plugins/KimaiPushBridgeBundle` in die Kimai-Instanz.

## Unterstützte Kimai-Events

- `App\Event\TimesheetCreatePostEvent`
- `App\Event\TimesheetRestartPostEvent`
- `App\Event\TimesheetStopPostEvent`
- `App\Event\WorkingTimeApproveMonthEvent`
- `App\Event\WorkingTimeUnlockMonthEvent`

Optional, wenn die jeweilige Kimai-Installation die Klassen bereitstellt:

- `App\Event\AbsenceRequestedEvent` oder `App\Event\AbsenceCreatedEvent`
- `App\Event\AbsenceApprovedEvent`
- `App\Event\AbsenceRejectedEvent`

## Konfiguration

Das Plugin funktioniert direkt nach dem Kopieren mit eingebauten Defaultwerten:

- `enabled: true`
- `relay_url: https://timai-push-plugin-kimai.vercel.app/api/webhooks/kimai`
- `webhook_secret: bxwlRDr7XChw4Ipbl7BLU2eFGcdnCSuaHAQ_Jl8aJ8k`
- `request_timeout: 5`

Wenn du die Defaults überschreiben willst, kannst du optional `config/packages/local.yaml` ergänzen:

```yaml
kimai_push_bridge:
  relay_url: 'https://timai-push-plugin-kimai.vercel.app/api/webhooks/kimai'
  webhook_secret: 'bxwlRDr7XChw4Ipbl7BLU2eFGcdnCSuaHAQ_Jl8aJ8k'
  request_timeout: 5
```

Alle Konfigurationswerte sind optional:

- `enabled` default `true`
- `relay_url` default eingebaut
- `webhook_secret` default eingebaut
- `request_timeout` default `5.0`

## Topic-Modell

Das Topic wird lokal deterministisch erzeugt:

```text
kimai_<normalized_instance>_<user_hash>
```

- `normalized_instance` wird automatisch aus Hostname und Basis-Pfad der aktuellen Kimai-URL normalisiert
- `user_hash` ist `substr(hash_hmac('sha256', normalized_instance . ':' . user_id, topic_secret), 0, 16)`
- `topic_secret` wird serverseitig generiert und nie an die App ausgeliefert

## Topic-Endpoint für die App

Das Bundle stellt einen authentifizierten API-Endpoint bereit:

```text
GET /api/push-bridge/topic
```

Antwort:

```json
{
  "topic": "kimai_example_com_ab12cd34ef56abcd",
  "normalized_instance": "example_com",
  "kimai_user_id": 123,
  "push_enabled": false
}
```

Die iOS-App soll dieses Topic vom Server beziehen und abonnieren. Sie muss das Topic nicht selbst aus einem Secret berechnen.

## User-Preferences fuer Push-Abos

Der technische App-Subscribe bleibt ein globaler Transport-Schalter:

- `kimai_push_bridge_enabled`

Zusaetzlich kann jeder User in den Kimai-Preferences pro Push-Typ steuern, welche Pushes fachlich zugelassen sind:

- `kimai_push_bridge_event_timer`
- `kimai_push_bridge_event_absence_requested`
- `kimai_push_bridge_event_absence_approved`
- `kimai_push_bridge_event_absence_rejected`
- `kimai_push_bridge_event_working_time_approved`
- `kimai_push_bridge_event_working_time_unlocked`

Fehlende Event-Preferences werden serverseitig als `true` interpretiert, damit bestehende Nutzer nach dem Upgrade keine Pushes verlieren.

## Subscribe- und Unsubscribe-Endpoint

Nachdem die App das Topic erfolgreich bei FCM abonniert hat, soll sie Kimai serverseitig aktivieren:

```text
POST /api/push-bridge/subscribe
```

Der Request soll als JSON gesendet werden:

```http
Content-Type: application/json

{}
```

Antwort:

```json
{
  "ok": true,
  "push_enabled": true,
  "topic": "kimai_example_com_ab12cd34ef56abcd",
  "normalized_instance": "example_com",
  "kimai_user_id": 123
}
```

Beim Logout oder Opt-out soll die App die Aktivierung wieder zurücknehmen:

```text
POST /api/push-bridge/unsubscribe
```

Auch dieser Request soll als JSON mit Body `{}` gesendet werden.

Antwort:

```json
{
  "ok": true,
  "push_enabled": false,
  "kimai_user_id": 123
}
```

## Verhalten

- Ein neuer aktiver Timer löst `timer.started` aus
- Ein Restart löst `timer.started` aus
- Ein Stop löst `timer.stopped` aus
- Eine Monatsfreigabe löst `working_time.approved` aus
- Eine Monatsentsperrung löst `working_time.unlocked` aus
- Events werden nur dann an den Relay gesendet, wenn der User Push serverseitig aktiviert hat und das Event-Abo fuer diesen Push-Typ aktiv ist
- Die sichtbare Push-Nachricht wird pro Empfaenger in dessen Kimai-Sprache erzeugt
- Requests mit `X-Timai-Client: ios` erzeugen keinen Push, damit die iOS-App keine Echo-Benachrichtigungen fuer ihre eigenen Aktionen bekommt
- Historisch abgeschlossene neu erstellte Einträge werden ignoriert
- Fehler beim Webhook-Dispatch werden nur geloggt und brechen Kimai nicht hart ab

## Installation in Kimai

1. Bundle in `var/plugins/KimaiPushBridgeBundle/` ablegen
2. Cache leeren:

```bash
bin/console cache:clear
```

3. Optional eine lokale Override-Konfiguration ergänzen
4. Optional prüfen, ob das Plugin erkannt wurde:

```bash
bin/console kimai:plugins
```

## Tests

Die Unit-Tests sind für Ausführung innerhalb einer Kimai-/PHPUnit-Umgebung gedacht:

```bash
php vendor/bin/phpunit var/plugins/KimaiPushBridgeBundle/Tests
```

## Lizenz

Dieses Plugin ist proprietär und wird unter "All Rights Reserved" bereitgestellt.

## Architekturhinweis für iOS

Der Push ist nur ein Sync-Signal. Die App darf beim Empfang oder beim Oeffnen der Mitteilung niemals blind lokal einen Timer starten oder stoppen. Sie soll das Topic über `GET /api/push-bridge/topic` beziehen, das Topic bei FCM abonnieren, danach `POST /api/push-bridge/subscribe` senden und UI oder Live Activity ausschließlich anhand des Serverzustands aktualisieren.
