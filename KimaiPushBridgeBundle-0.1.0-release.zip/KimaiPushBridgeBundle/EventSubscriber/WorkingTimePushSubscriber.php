<?php

declare(strict_types=1);

namespace KimaiPlugin\KimaiPushBridgeBundle\EventSubscriber;

use App\Event\WorkingTimeApproveMonthEvent;
use App\Event\WorkingTimeUnlockMonthEvent;
use KimaiPlugin\KimaiPushBridgeBundle\Service\WorkingTimePushDispatcher;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

final class WorkingTimePushSubscriber implements EventSubscriberInterface
{
    public function __construct(private readonly WorkingTimePushDispatcher $dispatcher)
    {
    }

    public static function getSubscribedEvents(): array
    {
        return [
            WorkingTimeApproveMonthEvent::class => 'onMonthApproved',
            WorkingTimeUnlockMonthEvent::class => 'onMonthUnlocked',
        ];
    }

    public function onMonthApproved(WorkingTimeApproveMonthEvent $event): void
    {
        $this->dispatcher->handleApproved($event->getMonth());
    }

    public function onMonthUnlocked(WorkingTimeUnlockMonthEvent $event): void
    {
        $this->dispatcher->handleUnlocked($event->getMonth());
    }
}
