<?php

declare(strict_types=1);

namespace KimaiPlugin\KimaiPushBridgeBundle\EventSubscriber;

use App\Event\TimesheetCreatePostEvent;
use App\Event\TimesheetRestartPostEvent;
use App\Event\TimesheetStopPostEvent;
use KimaiPlugin\KimaiPushBridgeBundle\Service\TimesheetPushDispatcher;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

final class TimesheetPushSubscriber implements EventSubscriberInterface
{
    public function __construct(private readonly TimesheetPushDispatcher $dispatcher)
    {
    }

    public static function getSubscribedEvents(): array
    {
        return [
            TimesheetCreatePostEvent::class => 'onTimesheetCreated',
            TimesheetRestartPostEvent::class => 'onTimesheetRestarted',
            TimesheetStopPostEvent::class => 'onTimesheetStopped',
        ];
    }

    public function onTimesheetCreated(TimesheetCreatePostEvent $event): void
    {
        $this->dispatcher->handleCreated($event->getTimesheet());
    }

    public function onTimesheetRestarted(TimesheetRestartPostEvent $event): void
    {
        $this->dispatcher->handleRestarted($event->getTimesheet());
    }

    public function onTimesheetStopped(TimesheetStopPostEvent $event): void
    {
        $this->dispatcher->handleStopped($event->getTimesheet());
    }
}
