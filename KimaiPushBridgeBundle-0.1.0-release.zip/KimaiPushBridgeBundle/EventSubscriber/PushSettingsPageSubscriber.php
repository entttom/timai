<?php

declare(strict_types=1);

namespace KimaiPlugin\KimaiPushBridgeBundle\EventSubscriber;

use App\Entity\User;
use App\Event\PageActionsEvent;
use App\EventSubscriber\Actions\AbstractActionsSubscriber;

final class PushSettingsPageSubscriber extends AbstractActionsSubscriber
{
    public static function getActionName(): string
    {
        return 'user_forms';
    }

    public function onActions(PageActionsEvent $event): void
    {
        $payload = $event->getPayload();

        /** @var User $user */
        $user = $payload['user'];

        if ($user->getId() === null || !$this->isGranted('preferences', $user)) {
            return;
        }

        $event->addAction('push-bridge', [
            'url' => $this->path('user_profile_push_bridge', ['username' => $user->getUserIdentifier()]),
            'title' => 'kimai_push_bridge.settings.nav',
        ]);
    }
}
