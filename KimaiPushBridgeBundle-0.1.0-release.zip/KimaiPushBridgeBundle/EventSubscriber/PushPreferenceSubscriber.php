<?php

declare(strict_types=1);

namespace KimaiPlugin\KimaiPushBridgeBundle\EventSubscriber;

use Symfony\Component\EventDispatcher\EventSubscriberInterface;

/**
 * Intentionally left empty.
 *
 * Older deployments injected push settings into the generic `/prefs` page via this
 * subscriber. Keeping a no-op class with the same name ensures that overwriting the
 * plugin directory removes that behavior even if deleted files are not cleaned up
 * properly on the target server.
 */
final class PushPreferenceSubscriber implements EventSubscriberInterface
{
    public static function getSubscribedEvents(): array
    {
        return [];
    }
}
