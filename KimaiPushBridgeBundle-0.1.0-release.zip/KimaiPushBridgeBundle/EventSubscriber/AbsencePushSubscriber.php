<?php

declare(strict_types=1);

namespace KimaiPlugin\KimaiPushBridgeBundle\EventSubscriber;

use App\Entity\User;
use KimaiPlugin\KimaiPushBridgeBundle\Service\AbsencePushDispatcher;
use Psr\Log\LoggerInterface;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

final class AbsencePushSubscriber implements EventSubscriberInterface
{
    /**
     * The public Kimai core in this repository snapshot does not expose the absence workflow classes.
     * We subscribe lazily to known class names so installations with the absence workflow can hook in
     * without breaking older Kimai versions.
     *
     * @var string[]
     */
    private const REQUESTED_EVENT_CLASSES = [
        'App\Event\AbsenceRequestedEvent',
        'App\Event\AbsenceRequestEvent',
        'App\Event\AbsenceCreatedEvent',
    ];

    /**
     * @var string[]
     */
    private const APPROVED_EVENT_CLASSES = [
        'App\Event\AbsenceApprovedEvent',
    ];

    /**
     * @var string[]
     */
    private const REJECTED_EVENT_CLASSES = [
        'App\Event\AbsenceRejectedEvent',
        'App\Event\AbsenceDeclinedEvent',
    ];

    public function __construct(
        private readonly AbsencePushDispatcher $dispatcher,
        private readonly LoggerInterface $logger
    ) {
    }

    public static function getSubscribedEvents(): array
    {
        $events = [];

        self::registerExistingClass(self::REQUESTED_EVENT_CLASSES, 'onAbsenceRequested', $events);
        self::registerExistingClass(self::APPROVED_EVENT_CLASSES, 'onAbsenceApproved', $events);
        self::registerExistingClass(self::REJECTED_EVENT_CLASSES, 'onAbsenceRejected', $events);

        return $events;
    }

    public function onAbsenceRequested(object $event): void
    {
        $absence = $this->extractAbsence($event);
        $absenceId = $this->extractPositiveInt($absence, ['getId']);
        $subjectUserId = $this->extractPositiveInt($absence, ['getUser', 'getOwner']);
        $recipient = $this->extractRecipient($event, ['getSupervisor', 'getApprover', 'getRecipient', 'getTeamlead'])
            ?? $this->extractRecipient($absence, ['getSupervisor', 'getApprover', 'getRecipient', 'getTeamlead']);

        if ($absenceId === null || $recipient === null) {
            $this->logger->debug('Skipping absence.requested push because the absence adapter could not resolve all required fields', [
                'event_class' => $event::class,
            ]);

            return;
        }

        $this->dispatcher->handleRequested($recipient, $absenceId, $subjectUserId);
    }

    public function onAbsenceApproved(object $event): void
    {
        $this->dispatchDecisionEvent($event, 'approved');
    }

    public function onAbsenceRejected(object $event): void
    {
        $this->dispatchDecisionEvent($event, 'rejected');
    }

    /**
     * @param array<string, string> $events
     */
    private static function registerExistingClass(array $candidates, string $method, array &$events): void
    {
        foreach ($candidates as $candidate) {
            if (class_exists($candidate)) {
                $events[$candidate] = $method;

                break;
            }
        }
    }

    private function dispatchDecisionEvent(object $event, string $state): void
    {
        $absence = $this->extractAbsence($event);
        $absenceId = $this->extractPositiveInt($absence, ['getId']);
        $recipient = $this->extractRecipient($absence, ['getUser', 'getOwner'])
            ?? $this->extractRecipient($event, ['getUser', 'getOwner', 'getRecipient']);
        $subjectUserId = $recipient?->getId();

        if ($absenceId === null || $recipient === null) {
            $this->logger->debug(sprintf('Skipping absence.%s push because the absence adapter could not resolve all required fields', $state), [
                'event_class' => $event::class,
            ]);

            return;
        }

        if ($state === 'approved') {
            $this->dispatcher->handleApproved($recipient, $absenceId, $subjectUserId);

            return;
        }

        $this->dispatcher->handleRejected($recipient, $absenceId, $subjectUserId);
    }

    private function extractAbsence(object $event): ?object
    {
        foreach (['getAbsence', 'getRequest', 'getEntity'] as $method) {
            if (!method_exists($event, $method)) {
                continue;
            }

            $value = $event->{$method}();
            if (is_object($value)) {
                return $value;
            }
        }

        return null;
    }

    /**
     * @param string[] $methods
     */
    private function extractRecipient(?object $source, array $methods): ?User
    {
        if ($source === null) {
            return null;
        }

        foreach ($methods as $method) {
            if (!method_exists($source, $method)) {
                continue;
            }

            $value = $source->{$method}();
            if ($value instanceof User) {
                return $value;
            }

            if (is_iterable($value)) {
                foreach ($value as $candidate) {
                    if ($candidate instanceof User) {
                        return $candidate;
                    }
                }
            }
        }

        return null;
    }

    /**
     * @param string[] $methods
     */
    private function extractPositiveInt(?object $source, array $methods): ?int
    {
        if ($source === null) {
            return null;
        }

        foreach ($methods as $method) {
            if (!method_exists($source, $method)) {
                continue;
            }

            $value = $source->{$method}();
            if ($value instanceof User) {
                $value = $value->getId();
            }

            if (is_int($value) && $value > 0) {
                return $value;
            }
        }

        return null;
    }
}
