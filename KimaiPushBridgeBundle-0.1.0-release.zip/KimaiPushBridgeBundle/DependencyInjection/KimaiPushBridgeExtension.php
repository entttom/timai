<?php

declare(strict_types=1);

namespace KimaiPlugin\KimaiPushBridgeBundle\DependencyInjection;

use App\Plugin\AbstractPluginExtension;
use Symfony\Component\Config\FileLocator;
use Symfony\Component\DependencyInjection\ContainerBuilder;
use Symfony\Component\DependencyInjection\Loader\YamlFileLoader;

final class KimaiPushBridgeExtension extends AbstractPluginExtension
{
    public function load(array $configs, ContainerBuilder $container): void
    {
        $configuration = new Configuration();
        $config = $this->processConfiguration($configuration, $configs);

        $this->registerBundleConfiguration($container, $config);

        $container->setParameter('kimai_push_bridge.enabled', $config['enabled']);
        $container->setParameter('kimai_push_bridge.relay_url', trim((string) $config['relay_url']));
        $container->setParameter('kimai_push_bridge.webhook_secret', (string) $config['webhook_secret']);
        $container->setParameter('kimai_push_bridge.request_timeout', (float) $config['request_timeout']);

        $loader = new YamlFileLoader($container, new FileLocator(__DIR__ . '/../Resources/config'));
        $loader->load('services.yaml');
    }

    public function getAlias(): string
    {
        return 'kimai_push_bridge';
    }
}
