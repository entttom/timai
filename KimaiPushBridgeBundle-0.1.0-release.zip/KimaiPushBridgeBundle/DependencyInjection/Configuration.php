<?php

declare(strict_types=1);

namespace KimaiPlugin\KimaiPushBridgeBundle\DependencyInjection;

use Symfony\Component\Config\Definition\Builder\TreeBuilder;
use Symfony\Component\Config\Definition\ConfigurationInterface;

final class Configuration implements ConfigurationInterface
{
    private const DEFAULT_RELAY_URL = 'https://timai-push-plugin-kimai.vercel.app/api/webhooks/kimai';
    private const DEFAULT_WEBHOOK_SECRET = 'bxwlRDr7XChw4Ipbl7BLU2eFGcdnCSuaHAQ_Jl8aJ8k';

    public function getConfigTreeBuilder(): TreeBuilder
    {
        $treeBuilder = new TreeBuilder('kimai_push_bridge');

        $treeBuilder->getRootNode()
            ->children()
                ->booleanNode('enabled')->defaultTrue()->end()
                ->scalarNode('relay_url')->defaultValue(self::DEFAULT_RELAY_URL)->cannotBeEmpty()->end()
                ->scalarNode('webhook_secret')->defaultValue(self::DEFAULT_WEBHOOK_SECRET)->cannotBeEmpty()->end()
                ->floatNode('request_timeout')->defaultValue(5.0)->min(0.1)->end()
            ->end()
        ;

        return $treeBuilder;
    }
}
