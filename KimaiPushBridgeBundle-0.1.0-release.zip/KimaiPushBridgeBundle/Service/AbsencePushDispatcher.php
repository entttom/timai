<?php

declare(strict_types=1);

namespace KimaiPlugin\KimaiPushBridgeBundle\Service;

use App\Entity\User;

final class AbsencePushDispatcher
{
    public function __construct(private readonly PushDispatcherInterface $dispatcher)
    {
    }

    public function handleRequested(User $recipient, int $absenceId, ?int $subjectUserId = null): void
    {
        $this->dispatch($recipient, PushEvents::ABSENCE_REQUESTED, 'absence-requested', $absenceId, $subjectUserId);
    }

    public function handleApproved(User $recipient, int $absenceId, ?int $subjectUserId = null): void
    {
        $this->dispatch($recipient, PushEvents::ABSENCE_APPROVED, 'absence-approved', $absenceId, $subjectUserId);
    }

    public function handleRejected(User $recipient, int $absenceId, ?int $subjectUserId = null): void
    {
        $this->dispatch($recipient, PushEvents::ABSENCE_REJECTED, 'absence-rejected', $absenceId, $subjectUserId);
    }

    private function dispatch(User $recipient, string $eventName, string $idempotencyPrefix, int $absenceId, ?int $subjectUserId): void
    {
        $recipientId = $recipient->getId();
        $idempotencyKey = $recipientId === null
            ? sprintf('%s-%d', $idempotencyPrefix, $absenceId)
            : sprintf('%s-%d-%d', $idempotencyPrefix, $absenceId, $recipientId);

        $payload = [
            'absence_id' => $absenceId,
            'idempotency_key' => $idempotencyKey,
        ];

        if ($subjectUserId !== null) {
            $payload['subject_kimai_user_id'] = $subjectUserId;
        }

        $this->dispatcher->dispatchToUser($recipient, $eventName, $payload, [], [
            'absence_id' => $absenceId,
            'subject_kimai_user_id' => $subjectUserId,
        ]);
    }
}
