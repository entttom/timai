<?php

declare(strict_types=1);

namespace KimaiPlugin\KimaiPushBridgeBundle\Service;

final class TopicNameGenerator
{
    private const INSTANCE_MAX_LENGTH = 32;
    private const USER_HASH_LENGTH = 16;

    public function generateTopic(string $normalizedInstance, int $userId, string $topicSecret): string
    {
        if ($userId <= 0) {
            throw new \InvalidArgumentException('User ID must be a positive integer.');
        }

        if ($topicSecret === '') {
            throw new \LogicException('Missing topic_secret configuration.');
        }

        if ($normalizedInstance === '') {
            throw new \LogicException('Could not derive a valid normalized instance name.');
        }

        $userHash = substr(hash_hmac('sha256', $normalizedInstance . ':' . $userId, $topicSecret), 0, self::USER_HASH_LENGTH);

        return sprintf('kimai_%s_%s', $normalizedInstance, $userHash);
    }

    public function normalizeInstanceName(string $instanceName): string
    {
        $ascii = trim($instanceName);
        if ($ascii === '') {
            return '';
        }

        if (function_exists('iconv')) {
            $transliterated = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $ascii);
            if (is_string($transliterated)) {
                $ascii = $transliterated;
            }
        }

        $ascii = strtolower($ascii);
        $ascii = preg_replace('/[^a-z0-9]+/', '_', $ascii) ?? '';
        $ascii = preg_replace('/_+/', '_', $ascii) ?? $ascii;
        $ascii = trim($ascii, '_');
        $ascii = substr($ascii, 0, self::INSTANCE_MAX_LENGTH);
        $ascii = rtrim($ascii, '_');

        return $ascii;
    }
}
