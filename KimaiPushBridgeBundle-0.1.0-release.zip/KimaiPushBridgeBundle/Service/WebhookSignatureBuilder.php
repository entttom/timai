<?php

declare(strict_types=1);

namespace KimaiPlugin\KimaiPushBridgeBundle\Service;

final class WebhookSignatureBuilder
{
    public function __construct(private readonly string $webhookSecret)
    {
    }

    /**
     * @param array<string, mixed> $payload
     */
    public function encodePayload(array $payload): string
    {
        try {
            return json_encode($payload, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        } catch (\JsonException $error) {
            throw new \RuntimeException('Failed to encode webhook payload.', 0, $error);
        }
    }

    public function sign(string $timestamp, string $rawBody): string
    {
        if ($this->webhookSecret === '') {
            throw new \LogicException('Missing webhook_secret configuration.');
        }

        return hash_hmac('sha256', $timestamp . '.' . $rawBody, $this->webhookSecret);
    }

    /**
     * @return array<string, string>
     */
    public function buildHeaders(string $eventName, string $rawBody, int $timestamp): array
    {
        $timestampString = (string) $timestamp;

        return [
            'Content-Type' => 'application/json',
            'X-Kimai-Timestamp' => $timestampString,
            'X-Kimai-Signature' => $this->sign($timestampString, $rawBody),
            'X-Kimai-Event' => $eventName,
        ];
    }
}
