<?php

declare(strict_types=1);

namespace KimaiPlugin\KimaiPushBridgeBundle\Service;

use App\Entity\User;

interface PushDispatcherInterface
{
    /**
     * @param array<string, mixed> $payload
     * @param array<string, mixed> $placeholderContext
     * @param array<string, mixed> $logContext
     */
    public function dispatchToUser(User $recipient, string $eventName, array $payload, array $placeholderContext = [], array $logContext = []): void;
}
