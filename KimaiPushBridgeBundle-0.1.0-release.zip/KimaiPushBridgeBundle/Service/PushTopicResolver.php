<?php

declare(strict_types=1);

namespace KimaiPlugin\KimaiPushBridgeBundle\Service;

final class PushTopicResolver
{
    public function __construct(
        private readonly TopicNameGenerator $topicNameGenerator,
        private readonly InstanceNameResolver $instanceNameResolver,
        private readonly TopicSecretProvider $topicSecretProvider
    ) {
    }

    /**
     * @return array{topic: string, normalized_instance: string}
     */
    public function resolveForUserId(int $userId): array
    {
        $normalizedInstance = $this->instanceNameResolver->resolveNormalizedInstanceName();
        $secret = $this->topicSecretProvider->getSecret();

        return [
            'topic' => $this->topicNameGenerator->generateTopic($normalizedInstance, $userId, $secret),
            'normalized_instance' => $normalizedInstance,
        ];
    }
}
