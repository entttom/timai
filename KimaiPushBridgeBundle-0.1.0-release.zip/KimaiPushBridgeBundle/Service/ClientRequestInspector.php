<?php

declare(strict_types=1);

namespace KimaiPlugin\KimaiPushBridgeBundle\Service;

use Symfony\Component\HttpFoundation\RequestStack;

final class ClientRequestInspector
{
    public const HEADER_NAME = 'X-Timai-Client';
    public const CLIENT_IOS = 'ios';

    public function __construct(private readonly RequestStack $requestStack)
    {
    }

    public function isIosAppRequest(): bool
    {
        $request = null;

        if (method_exists($this->requestStack, 'getMainRequest')) {
            $request = $this->requestStack->getMainRequest();
        } elseif (method_exists($this->requestStack, 'getMasterRequest')) {
            $request = $this->requestStack->getMasterRequest();
        }

        $request ??= $this->requestStack->getCurrentRequest();
        if ($request === null) {
            return false;
        }

        $client = trim((string) $request->headers->get(self::HEADER_NAME, ''));

        return strtolower($client) === self::CLIENT_IOS;
    }
}
