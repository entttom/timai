<?php

declare(strict_types=1);

namespace KimaiPlugin\KimaiPushBridgeBundle\Service;

use App\Entity\User;

final class PushSubscriptionManager
{
    public const PREFERENCE_NAME = 'kimai_push_bridge_enabled';
    public const PREFERENCE_EVENT_TIMER = 'kimai_push_bridge_event_timer';
    public const PREFERENCE_EVENT_ABSENCE_REQUESTED = 'kimai_push_bridge_event_absence_requested';
    public const PREFERENCE_EVENT_ABSENCE_APPROVED = 'kimai_push_bridge_event_absence_approved';
    public const PREFERENCE_EVENT_ABSENCE_REJECTED = 'kimai_push_bridge_event_absence_rejected';
    public const PREFERENCE_EVENT_WORKING_TIME_APPROVED = 'kimai_push_bridge_event_working_time_approved';
    public const PREFERENCE_EVENT_WORKING_TIME_UNLOCKED = 'kimai_push_bridge_event_working_time_unlocked';
    public const PREFERENCE_CUSTOM_TITLE = 'kimai_push_bridge_custom_title';
    public const PREFERENCE_CUSTOM_BODY = 'kimai_push_bridge_custom_body';
    public const PREFERENCE_TIMER_STARTED_TITLE = 'kimai_push_bridge_timer_started_title';
    public const PREFERENCE_TIMER_STARTED_BODY = 'kimai_push_bridge_timer_started_body';
    public const PREFERENCE_TIMER_STOPPED_TITLE = 'kimai_push_bridge_timer_stopped_title';
    public const PREFERENCE_TIMER_STOPPED_BODY = 'kimai_push_bridge_timer_stopped_body';
    public const PREFERENCE_ABSENCE_REQUESTED_TITLE = 'kimai_push_bridge_absence_requested_title';
    public const PREFERENCE_ABSENCE_REQUESTED_BODY = 'kimai_push_bridge_absence_requested_body';
    public const PREFERENCE_ABSENCE_APPROVED_TITLE = 'kimai_push_bridge_absence_approved_title';
    public const PREFERENCE_ABSENCE_APPROVED_BODY = 'kimai_push_bridge_absence_approved_body';
    public const PREFERENCE_ABSENCE_REJECTED_TITLE = 'kimai_push_bridge_absence_rejected_title';
    public const PREFERENCE_ABSENCE_REJECTED_BODY = 'kimai_push_bridge_absence_rejected_body';
    public const PREFERENCE_WORKING_TIME_APPROVED_TITLE = 'kimai_push_bridge_working_time_approved_title';
    public const PREFERENCE_WORKING_TIME_APPROVED_BODY = 'kimai_push_bridge_working_time_approved_body';
    public const PREFERENCE_WORKING_TIME_UNLOCKED_TITLE = 'kimai_push_bridge_working_time_unlocked_title';
    public const PREFERENCE_WORKING_TIME_UNLOCKED_BODY = 'kimai_push_bridge_working_time_unlocked_body';

    /**
     * @var array<string, string>
     */
    private const EVENT_TO_PREFERENCE_MAP = [
        PushEvents::TIMER_STARTED => self::PREFERENCE_EVENT_TIMER,
        PushEvents::TIMER_STOPPED => self::PREFERENCE_EVENT_TIMER,
        PushEvents::ABSENCE_REQUESTED => self::PREFERENCE_EVENT_ABSENCE_REQUESTED,
        PushEvents::ABSENCE_APPROVED => self::PREFERENCE_EVENT_ABSENCE_APPROVED,
        PushEvents::ABSENCE_REJECTED => self::PREFERENCE_EVENT_ABSENCE_REJECTED,
        PushEvents::WORKING_TIME_APPROVED => self::PREFERENCE_EVENT_WORKING_TIME_APPROVED,
        PushEvents::WORKING_TIME_UNLOCKED => self::PREFERENCE_EVENT_WORKING_TIME_UNLOCKED,
    ];

    /**
     * @var array<string, array{title: string, body: string}>
     */
    private const EVENT_TO_MESSAGE_PREFERENCE_MAP = [
        PushEvents::TIMER_STARTED => [
            'title' => self::PREFERENCE_TIMER_STARTED_TITLE,
            'body' => self::PREFERENCE_TIMER_STARTED_BODY,
        ],
        PushEvents::TIMER_STOPPED => [
            'title' => self::PREFERENCE_TIMER_STOPPED_TITLE,
            'body' => self::PREFERENCE_TIMER_STOPPED_BODY,
        ],
        PushEvents::ABSENCE_REQUESTED => [
            'title' => self::PREFERENCE_ABSENCE_REQUESTED_TITLE,
            'body' => self::PREFERENCE_ABSENCE_REQUESTED_BODY,
        ],
        PushEvents::ABSENCE_APPROVED => [
            'title' => self::PREFERENCE_ABSENCE_APPROVED_TITLE,
            'body' => self::PREFERENCE_ABSENCE_APPROVED_BODY,
        ],
        PushEvents::ABSENCE_REJECTED => [
            'title' => self::PREFERENCE_ABSENCE_REJECTED_TITLE,
            'body' => self::PREFERENCE_ABSENCE_REJECTED_BODY,
        ],
        PushEvents::WORKING_TIME_APPROVED => [
            'title' => self::PREFERENCE_WORKING_TIME_APPROVED_TITLE,
            'body' => self::PREFERENCE_WORKING_TIME_APPROVED_BODY,
        ],
        PushEvents::WORKING_TIME_UNLOCKED => [
            'title' => self::PREFERENCE_WORKING_TIME_UNLOCKED_TITLE,
            'body' => self::PREFERENCE_WORKING_TIME_UNLOCKED_BODY,
        ],
    ];

    /**
     * @return array<int, array{name: string, label: string, help: string, default: bool, order: int}>
     */
    public static function getEventPreferenceDefinitions(): array
    {
        return [
            [
                'name' => self::PREFERENCE_EVENT_TIMER,
                'label' => 'kimai_push_bridge.preference.timer',
                'help' => 'kimai_push_bridge.preference_help.timer',
                'default' => true,
                'order' => 1600,
            ],
            [
                'name' => self::PREFERENCE_EVENT_ABSENCE_REQUESTED,
                'label' => 'kimai_push_bridge.preference.absence_requested',
                'help' => 'kimai_push_bridge.preference_help.absence_requested',
                'default' => true,
                'order' => 1610,
            ],
            [
                'name' => self::PREFERENCE_EVENT_ABSENCE_APPROVED,
                'label' => 'kimai_push_bridge.preference.absence_approved',
                'help' => 'kimai_push_bridge.preference_help.absence_approved',
                'default' => true,
                'order' => 1620,
            ],
            [
                'name' => self::PREFERENCE_EVENT_ABSENCE_REJECTED,
                'label' => 'kimai_push_bridge.preference.absence_rejected',
                'help' => 'kimai_push_bridge.preference_help.absence_rejected',
                'default' => true,
                'order' => 1630,
            ],
            [
                'name' => self::PREFERENCE_EVENT_WORKING_TIME_APPROVED,
                'label' => 'kimai_push_bridge.preference.working_time_approved',
                'help' => 'kimai_push_bridge.preference_help.working_time_approved',
                'default' => true,
                'order' => 1640,
            ],
            [
                'name' => self::PREFERENCE_EVENT_WORKING_TIME_UNLOCKED,
                'label' => 'kimai_push_bridge.preference.working_time_unlocked',
                'help' => 'kimai_push_bridge.preference_help.working_time_unlocked',
                'default' => true,
                'order' => 1650,
            ],
        ];
    }

    public function isPushEnabled(User $user): bool
    {
        return (bool) $user->getPreferenceValue(self::PREFERENCE_NAME, false, false);
    }

    public function isEventSubscribed(User $user, string $eventName): bool
    {
        $preferenceName = self::EVENT_TO_PREFERENCE_MAP[$eventName] ?? null;
        if ($preferenceName === null) {
            return false;
        }

        return (bool) $user->getPreferenceValue($preferenceName, true, false);
    }

    public function subscribe(User $user): void
    {
        $user->setPreferenceValue(self::PREFERENCE_NAME, true);
    }

    public function unsubscribe(User $user): void
    {
        $user->setPreferenceValue(self::PREFERENCE_NAME, false);
    }

    public function getCustomTitle(User $user): ?string
    {
        return $this->normalizeTextPreference($user->getPreferenceValue(self::PREFERENCE_CUSTOM_TITLE, null, false));
    }

    public function getCustomBody(User $user): ?string
    {
        return $this->normalizeTextPreference($user->getPreferenceValue(self::PREFERENCE_CUSTOM_BODY, null, false));
    }

    public function setCustomTitle(User $user, ?string $title): void
    {
        $user->setPreferenceValue(self::PREFERENCE_CUSTOM_TITLE, $this->normalizeTextPreference($title));
    }

    public function setCustomBody(User $user, ?string $body): void
    {
        $user->setPreferenceValue(self::PREFERENCE_CUSTOM_BODY, $this->normalizeTextPreference($body));
    }

    public function getCustomTitleForEvent(User $user, string $eventName): ?string
    {
        $preferenceName = $this->messagePreferenceNameForEvent($eventName, 'title');
        $eventSpecific = $preferenceName === null ? null : $this->normalizeTextPreference($user->getPreferenceValue($preferenceName, null, false));

        return $eventSpecific ?? $this->getCustomTitle($user);
    }

    public function getCustomBodyForEvent(User $user, string $eventName): ?string
    {
        $preferenceName = $this->messagePreferenceNameForEvent($eventName, 'body');
        $eventSpecific = $preferenceName === null ? null : $this->normalizeTextPreference($user->getPreferenceValue($preferenceName, null, false));

        return $eventSpecific ?? $this->getCustomBody($user);
    }

    public function setCustomTitleForEvent(User $user, string $eventName, ?string $title): void
    {
        $preferenceName = $this->messagePreferenceNameForEvent($eventName, 'title');
        if ($preferenceName === null) {
            return;
        }

        $user->setPreferenceValue($preferenceName, $this->normalizeTextPreference($title));
    }

    public function setCustomBodyForEvent(User $user, string $eventName, ?string $body): void
    {
        $preferenceName = $this->messagePreferenceNameForEvent($eventName, 'body');
        if ($preferenceName === null) {
            return;
        }

        $user->setPreferenceValue($preferenceName, $this->normalizeTextPreference($body));
    }

    /**
     * @return array<int, array{event: string, label: string, title_preference: string, body_preference: string}>
     */
    public static function getCustomMessageDefinitions(): array
    {
        return [
            [
                'event' => PushEvents::TIMER_STARTED,
                'label' => 'kimai_push_bridge.event.timer_started',
                'title_preference' => self::PREFERENCE_TIMER_STARTED_TITLE,
                'body_preference' => self::PREFERENCE_TIMER_STARTED_BODY,
            ],
            [
                'event' => PushEvents::TIMER_STOPPED,
                'label' => 'kimai_push_bridge.event.timer_stopped',
                'title_preference' => self::PREFERENCE_TIMER_STOPPED_TITLE,
                'body_preference' => self::PREFERENCE_TIMER_STOPPED_BODY,
            ],
            [
                'event' => PushEvents::ABSENCE_REQUESTED,
                'label' => 'kimai_push_bridge.event.absence_requested',
                'title_preference' => self::PREFERENCE_ABSENCE_REQUESTED_TITLE,
                'body_preference' => self::PREFERENCE_ABSENCE_REQUESTED_BODY,
            ],
            [
                'event' => PushEvents::ABSENCE_APPROVED,
                'label' => 'kimai_push_bridge.event.absence_approved',
                'title_preference' => self::PREFERENCE_ABSENCE_APPROVED_TITLE,
                'body_preference' => self::PREFERENCE_ABSENCE_APPROVED_BODY,
            ],
            [
                'event' => PushEvents::ABSENCE_REJECTED,
                'label' => 'kimai_push_bridge.event.absence_rejected',
                'title_preference' => self::PREFERENCE_ABSENCE_REJECTED_TITLE,
                'body_preference' => self::PREFERENCE_ABSENCE_REJECTED_BODY,
            ],
            [
                'event' => PushEvents::WORKING_TIME_APPROVED,
                'label' => 'kimai_push_bridge.event.working_time_approved',
                'title_preference' => self::PREFERENCE_WORKING_TIME_APPROVED_TITLE,
                'body_preference' => self::PREFERENCE_WORKING_TIME_APPROVED_BODY,
            ],
            [
                'event' => PushEvents::WORKING_TIME_UNLOCKED,
                'label' => 'kimai_push_bridge.event.working_time_unlocked',
                'title_preference' => self::PREFERENCE_WORKING_TIME_UNLOCKED_TITLE,
                'body_preference' => self::PREFERENCE_WORKING_TIME_UNLOCKED_BODY,
            ],
        ];
    }

    private function messagePreferenceNameForEvent(string $eventName, string $type): ?string
    {
        return self::EVENT_TO_MESSAGE_PREFERENCE_MAP[$eventName][$type] ?? null;
    }

    private function normalizeTextPreference(string|int|float|bool|null $value): ?string
    {
        $normalized = trim((string) ($value ?? ''));

        return $normalized === '' ? null : $normalized;
    }
}
