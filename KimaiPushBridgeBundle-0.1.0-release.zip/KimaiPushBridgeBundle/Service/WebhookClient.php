<?php

declare(strict_types=1);

namespace KimaiPlugin\KimaiPushBridgeBundle\Service;

use Psr\Log\LoggerInterface;
use Symfony\Contracts\HttpClient\HttpClientInterface;

final class WebhookClient
{
    public function __construct(
        private readonly HttpClientInterface $httpClient,
        private readonly WebhookSignatureBuilder $signatureBuilder,
        private readonly LoggerInterface $logger,
        private readonly string $relayUrl,
        private readonly float $requestTimeout
    ) {
    }

    /**
     * @param array<string, mixed> $payload
     */
    public function send(string $eventName, array $payload): void
    {
        if ($this->relayUrl === '') {
            throw new \LogicException('Missing relay_url configuration.');
        }

        $rawBody = $this->signatureBuilder->encodePayload($payload);
        $headers = $this->signatureBuilder->buildHeaders($eventName, $rawBody, time());

        try {
            $response = $this->httpClient->request('POST', $this->relayUrl, [
                'headers' => $headers,
                'body' => $rawBody,
                'timeout' => $this->requestTimeout > 0 ? $this->requestTimeout : 5.0,
            ]);

            $statusCode = $response->getStatusCode();
            if ($statusCode < 200 || $statusCode >= 300) {
                $this->logger->warning('Relay webhook returned a non-success status', [
                    'event' => $eventName,
                    'status_code' => $statusCode,
                ]);

                throw new \RuntimeException(sprintf('Relay webhook returned status code %d.', $statusCode));
            }
        } catch (\Throwable $error) {
            throw new \RuntimeException('Failed to send relay webhook.', 0, $error);
        }
    }
}
