<?php

declare(strict_types=1);

namespace KimaiPlugin\KimaiPushBridgeBundle\Service;

use App\Entity\User;
use Symfony\Contracts\Translation\TranslatorInterface;

final class PushMessageBuilder
{
    private const DEFAULT_LANGUAGE = 'en';
    private const TITLE_KEY = 'kimai_push_bridge.push.title';
    private const PLACEHOLDER_EVENT = '%event%';
    private const PLACEHOLDER_CUSTOMER = '%customer%';
    private const PLACEHOLDER_KUNDE = '%kunde%';
    private const PLACEHOLDER_PROJECT = '%project%';
    private const PLACEHOLDER_PROJECT_NAME = '%projektname%';
    private const PLACEHOLDER_ACTIVITY = '%activity%';
    private const PLACEHOLDER_AKTIVITAET = '%aktivitaet%';
    private const PLACEHOLDER_AKTIVITAET_UMLAUT = '%aktivität%';
    private const PLACEHOLDER_START_TIME = '%starttime%';
    private const PLACEHOLDER_STARTZEIT = '%startzeit%';

    public function __construct(
        private readonly TranslatorInterface $translator,
        private readonly PushSubscriptionManager $pushSubscriptionManager
    )
    {
    }

    /**
     * @return array{language: string, title: string, body: string}
     */
    public function build(User $recipient, string $eventName, array $placeholderContext = []): array
    {
        $language = $this->resolveLanguage($recipient);
        $eventLabel = $this->translate($this->labelKeyForEvent($eventName), $language);
        $defaultTitle = $this->translate(self::TITLE_KEY, $language);
        $defaultBody = $this->translate($this->bodyKeyForEvent($eventName), $language);
        $placeholders = $this->buildPlaceholders($eventLabel, $placeholderContext);

        return [
            'language' => $language,
            'title' => $this->renderTemplate($this->pushSubscriptionManager->getCustomTitleForEvent($recipient, $eventName), $defaultTitle, $placeholders),
            'body' => $this->renderTemplate($this->pushSubscriptionManager->getCustomBodyForEvent($recipient, $eventName), $defaultBody, $placeholders),
        ];
    }

    /**
     * @return array<int, array{event: string, label: string, title: string, body: string, defaultTitle: string, defaultBody: string, placeholders: array<string, string>}>
     */
    public function buildPreviews(User $recipient, array $timerPlaceholderContext = []): array
    {
        $previews = [];
        $language = $this->resolveLanguage($recipient);

        foreach ($this->previewEvents() as $eventName) {
            $eventLabel = $this->translate($this->labelKeyForEvent($eventName), $language);
            $defaultTitle = $this->translate(self::TITLE_KEY, $language);
            $defaultBody = $this->translate($this->bodyKeyForEvent($eventName), $language);
            $placeholderContext = $this->previewPlaceholderContext($eventName, $language, $timerPlaceholderContext);
            $message = $this->build($recipient, $eventName, $placeholderContext);
            $previews[] = [
                'event' => $eventName,
                'label' => $eventLabel,
                'title' => $message['title'],
                'body' => $message['body'],
                'defaultTitle' => $defaultTitle,
                'defaultBody' => $defaultBody,
                'placeholders' => $this->buildPlaceholders($eventLabel, $placeholderContext),
            ];
        }

        return $previews;
    }

    private function resolveLanguage(User $recipient): string
    {
        $language = trim($recipient->getLanguage());

        return $language !== '' ? $language : self::DEFAULT_LANGUAGE;
    }

    private function bodyKeyForEvent(string $eventName): string
    {
        return match ($eventName) {
            PushEvents::TIMER_STARTED => 'kimai_push_bridge.push.timer_started',
            PushEvents::TIMER_STOPPED => 'kimai_push_bridge.push.timer_stopped',
            PushEvents::ABSENCE_REQUESTED => 'kimai_push_bridge.push.absence_requested',
            PushEvents::ABSENCE_APPROVED => 'kimai_push_bridge.push.absence_approved',
            PushEvents::ABSENCE_REJECTED => 'kimai_push_bridge.push.absence_rejected',
            PushEvents::WORKING_TIME_APPROVED => 'kimai_push_bridge.push.working_time_approved',
            PushEvents::WORKING_TIME_UNLOCKED => 'kimai_push_bridge.push.working_time_unlocked',
            default => throw new \InvalidArgumentException(sprintf('Unsupported push event: %s', $eventName)),
        };
    }

    private function labelKeyForEvent(string $eventName): string
    {
        return match ($eventName) {
            PushEvents::TIMER_STARTED => 'kimai_push_bridge.event.timer_started',
            PushEvents::TIMER_STOPPED => 'kimai_push_bridge.event.timer_stopped',
            PushEvents::ABSENCE_REQUESTED => 'kimai_push_bridge.event.absence_requested',
            PushEvents::ABSENCE_APPROVED => 'kimai_push_bridge.event.absence_approved',
            PushEvents::ABSENCE_REJECTED => 'kimai_push_bridge.event.absence_rejected',
            PushEvents::WORKING_TIME_APPROVED => 'kimai_push_bridge.event.working_time_approved',
            PushEvents::WORKING_TIME_UNLOCKED => 'kimai_push_bridge.event.working_time_unlocked',
            default => throw new \InvalidArgumentException(sprintf('Unsupported push event: %s', $eventName)),
        };
    }

    /**
     * @return array<int, string>
     */
    private function previewEvents(): array
    {
        return [
            PushEvents::TIMER_STARTED,
            PushEvents::TIMER_STOPPED,
            PushEvents::ABSENCE_REQUESTED,
            PushEvents::ABSENCE_APPROVED,
            PushEvents::ABSENCE_REJECTED,
            PushEvents::WORKING_TIME_APPROVED,
            PushEvents::WORKING_TIME_UNLOCKED,
        ];
    }

    /**
     * @param array<string, string> $placeholders
     */
    private function renderTemplate(?string $template, string $fallback, array $placeholders): string
    {
        if ($template === null) {
            return $fallback;
        }

        $rendered = trim(strtr($template, $placeholders));

        return $rendered !== '' ? $rendered : $fallback;
    }

    /**
     * @param array<string, mixed> $placeholderContext
     *
     * @return array<string, string>
     */
    private function buildPlaceholders(string $eventLabel, array $placeholderContext): array
    {
        $customer = $this->normalizePlaceholderValue($placeholderContext['customer'] ?? null);
        $project = $this->normalizePlaceholderValue($placeholderContext['project'] ?? null);
        $activity = $this->normalizePlaceholderValue($placeholderContext['activity'] ?? null);
        $startTime = $this->normalizePlaceholderValue($placeholderContext['starttime'] ?? null);

        return [
            self::PLACEHOLDER_EVENT => $eventLabel,
            self::PLACEHOLDER_CUSTOMER => $customer,
            self::PLACEHOLDER_KUNDE => $customer,
            self::PLACEHOLDER_PROJECT => $project,
            self::PLACEHOLDER_PROJECT_NAME => $project,
            self::PLACEHOLDER_ACTIVITY => $activity,
            self::PLACEHOLDER_AKTIVITAET => $activity,
            self::PLACEHOLDER_AKTIVITAET_UMLAUT => $activity,
            self::PLACEHOLDER_START_TIME => $startTime,
            self::PLACEHOLDER_STARTZEIT => $startTime,
        ];
    }

    /**
     * @return array<string, string>
     */
    private function previewPlaceholderContext(string $eventName, string $language, array $timerPlaceholderContext): array
    {
        if (!in_array($eventName, [PushEvents::TIMER_STARTED, PushEvents::TIMER_STOPPED], true)) {
            return [];
        }

        if ($timerPlaceholderContext !== []) {
            return [
                'customer' => $this->normalizePlaceholderValue($timerPlaceholderContext['customer'] ?? null),
                'project' => $this->normalizePlaceholderValue($timerPlaceholderContext['project'] ?? null),
                'activity' => $this->normalizePlaceholderValue($timerPlaceholderContext['activity'] ?? null),
                'starttime' => $this->normalizePlaceholderValue($timerPlaceholderContext['starttime'] ?? null),
            ];
        }

        return [
            'customer' => $this->translate('kimai_push_bridge.preview.customer', $language),
            'project' => $this->translate('kimai_push_bridge.preview.project', $language),
            'activity' => $this->translate('kimai_push_bridge.preview.activity', $language),
            'starttime' => '08:30',
        ];
    }

    private function normalizePlaceholderValue(mixed $value): string
    {
        if (!is_scalar($value) && $value !== null) {
            return '';
        }

        return trim((string) ($value ?? ''));
    }

    private function translate(string $key, string $language): string
    {
        $translated = $this->translator->trans($key, [], 'messages', $language);

        if ($translated === $key && $language !== self::DEFAULT_LANGUAGE) {
            return $this->translator->trans($key, [], 'messages', self::DEFAULT_LANGUAGE);
        }

        return $translated;
    }
}
