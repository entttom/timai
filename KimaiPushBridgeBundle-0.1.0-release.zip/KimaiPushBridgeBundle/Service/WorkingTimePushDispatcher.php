<?php

declare(strict_types=1);

namespace KimaiPlugin\KimaiPushBridgeBundle\Service;

use App\WorkingTime\Model\Month;
use Psr\Log\LoggerInterface;

final class WorkingTimePushDispatcher
{
    public function __construct(
        private readonly PushDispatcherInterface $dispatcher,
        private readonly LoggerInterface $logger
    ) {
    }

    public function handleApproved(Month $month): void
    {
        $this->dispatch($month, PushEvents::WORKING_TIME_APPROVED, 'working-time-approved');
    }

    public function handleUnlocked(Month $month): void
    {
        $this->dispatch($month, PushEvents::WORKING_TIME_UNLOCKED, 'working-time-unlocked');
    }

    private function dispatch(Month $month, string $eventName, string $idempotencyPrefix): void
    {
        $user = $month->getUser();
        $userId = $user->getId();
        $monthDate = $month->getMonth();

        if ($userId === null) {
            $this->logger->warning('Skipping working time push dispatch because the month user is missing an identifier', [
                'event' => $eventName,
            ]);

            return;
        }

        $year = (int) $monthDate->format('Y');
        $monthNumber = (int) $monthDate->format('n');

        $this->dispatcher->dispatchToUser($user, $eventName, [
            'year' => $year,
            'month' => $monthNumber,
            'idempotency_key' => sprintf('%s-%d-%04d-%02d', $idempotencyPrefix, $userId, $year, $monthNumber),
        ], [], [
            'year' => $year,
            'month' => $monthNumber,
        ]);
    }
}
