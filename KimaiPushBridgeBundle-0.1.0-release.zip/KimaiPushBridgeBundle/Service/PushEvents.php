<?php

declare(strict_types=1);

namespace KimaiPlugin\KimaiPushBridgeBundle\Service;

final class PushEvents
{
    public const TIMER_STARTED = 'timer.started';
    public const TIMER_STOPPED = 'timer.stopped';
    public const ABSENCE_REQUESTED = 'absence.requested';
    public const ABSENCE_APPROVED = 'absence.approved';
    public const ABSENCE_REJECTED = 'absence.rejected';
    public const WORKING_TIME_APPROVED = 'working_time.approved';
    public const WORKING_TIME_UNLOCKED = 'working_time.unlocked';

    /**
     * @return string[]
     */
    public static function all(): array
    {
        return [
            self::TIMER_STARTED,
            self::TIMER_STOPPED,
            self::ABSENCE_REQUESTED,
            self::ABSENCE_APPROVED,
            self::ABSENCE_REJECTED,
            self::WORKING_TIME_APPROVED,
            self::WORKING_TIME_UNLOCKED,
        ];
    }
}
