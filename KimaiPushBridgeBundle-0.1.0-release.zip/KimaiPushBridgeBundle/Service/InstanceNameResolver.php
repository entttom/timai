<?php

declare(strict_types=1);

namespace KimaiPlugin\KimaiPushBridgeBundle\Service;

use Symfony\Component\HttpFoundation\RequestStack;
use Symfony\Component\Routing\RequestContext;

final class InstanceNameResolver
{
    public function __construct(
        private readonly RequestStack $requestStack,
        private readonly RequestContext $requestContext,
        private readonly TopicNameGenerator $topicNameGenerator
    ) {
    }

    public function resolveNormalizedInstanceName(): string
    {
        $host = '';
        $basePath = '';
        $request = $this->requestStack->getCurrentRequest();

        if ($request !== null) {
            $host = $request->getHost();
            $basePath = $request->getBaseUrl();
        }

        if ($host === '') {
            $host = $this->requestContext->getHost();
            $basePath = $this->requestContext->getBaseUrl();
        }

        $source = trim($host);
        $basePath = trim($basePath);

        if ($basePath !== '' && $basePath !== '/') {
            $source .= $basePath;
        }

        if ($source === '') {
            throw new \RuntimeException('Unable to resolve Kimai instance name from the current request context.');
        }

        return $this->topicNameGenerator->normalizeInstanceName($source);
    }
}
