<?php

declare(strict_types=1);

namespace KimaiPlugin\KimaiPushBridgeBundle\Service;

use App\Entity\Timesheet;
use Psr\Log\LoggerInterface;

final class TimesheetPushDispatcher
{
    public function __construct(
        private readonly PushDispatcherInterface $dispatcher,
        private readonly LoggerInterface $logger
    ) {
    }

    public function handleCreated(Timesheet $timesheet): void
    {
        if (!$timesheet->isRunning()) {
            $this->logger->debug('Ignoring completed timesheet creation event', [
                'timesheet_id' => $timesheet->getId(),
            ]);

            return;
        }

        $this->dispatch($timesheet, PushEvents::TIMER_STARTED, 'timer-start');
    }

    public function handleRestarted(Timesheet $timesheet): void
    {
        if (!$timesheet->isRunning()) {
            $this->logger->warning('Ignoring restarted timesheet that is no longer running', [
                'timesheet_id' => $timesheet->getId(),
            ]);

            return;
        }

        $this->dispatch($timesheet, PushEvents::TIMER_STARTED, 'timer-start');
    }

    public function handleStopped(Timesheet $timesheet): void
    {
        if ($timesheet->isRunning()) {
            $this->logger->warning('Ignoring stop event for timesheet without end timestamp', [
                'timesheet_id' => $timesheet->getId(),
            ]);

            return;
        }

        $this->dispatch($timesheet, PushEvents::TIMER_STOPPED, 'timer-stop');
    }

    private function dispatch(Timesheet $timesheet, string $eventName, string $idempotencyPrefix): void
    {
        $timesheetId = $timesheet->getId();
        $user = $timesheet->getUser();
        $userId = $user?->getId();

        if ($timesheetId === null || $userId === null) {
            $this->logger->warning('Skipping push dispatch because required identifiers are missing', [
                'event' => $eventName,
                'timesheet_id' => $timesheetId,
                'user_id' => $userId,
            ]);

            return;
        }

        $this->dispatcher->dispatchToUser($user, $eventName, [
            'timesheet_id' => $timesheetId,
            'idempotency_key' => sprintf('%s-%d', $idempotencyPrefix, $timesheetId),
        ], $this->buildPlaceholderContext($timesheet), [
            'timesheet_id' => $timesheetId,
        ]);
    }

    /**
     * @return array<string, string>
     */
    private function buildPlaceholderContext(Timesheet $timesheet): array
    {
        $project = $timesheet->getProject();
        $customer = $project?->getCustomer();
        $activity = $timesheet->getActivity();
        $begin = $timesheet->getBegin();

        return [
            'customer' => trim((string) ($customer?->getName() ?? '')),
            'project' => trim((string) ($project?->getName() ?? '')),
            'activity' => trim((string) ($activity?->getName() ?? '')),
            'starttime' => $begin?->format('H:i') ?? '',
        ];
    }
}
