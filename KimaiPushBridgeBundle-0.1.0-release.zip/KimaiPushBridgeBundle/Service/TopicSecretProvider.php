<?php

declare(strict_types=1);

namespace KimaiPlugin\KimaiPushBridgeBundle\Service;

use Psr\Log\LoggerInterface;

final class TopicSecretProvider
{
    private const DIRECTORY = 'kimai_push_bridge';
    private const FILE_NAME = 'topic_secret';

    public function __construct(
        private readonly string $dataDir,
        private readonly LoggerInterface $logger
    ) {
    }

    public function getSecret(): string
    {
        $path = $this->getSecretPath();

        if (is_file($path)) {
            $secret = trim((string) file_get_contents($path));
            if ($secret !== '') {
                return $secret;
            }
        }

        $directory = dirname($path);
        if (!is_dir($directory) && !@mkdir($directory, 0700, true) && !is_dir($directory)) {
            throw new \RuntimeException(sprintf('Unable to create topic secret directory: %s', $directory));
        }

        $secret = bin2hex(random_bytes(32));
        $temporaryPath = $path . '.' . bin2hex(random_bytes(6)) . '.tmp';

        if (file_put_contents($temporaryPath, $secret . PHP_EOL, LOCK_EX) === false) {
            throw new \RuntimeException('Failed to persist generated topic secret.');
        }

        @chmod($temporaryPath, 0600);

        if (!@rename($temporaryPath, $path)) {
            @unlink($temporaryPath);

            if (is_file($path)) {
                $existing = trim((string) file_get_contents($path));
                if ($existing !== '') {
                    return $existing;
                }
            }

            throw new \RuntimeException('Failed to finalize generated topic secret.');
        }

        $this->logger->info('Generated Kimai Push Bridge topic secret', [
            'path' => $path,
        ]);

        return $secret;
    }

    private function getSecretPath(): string
    {
        return rtrim($this->dataDir, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . self::DIRECTORY . DIRECTORY_SEPARATOR . self::FILE_NAME;
    }
}
