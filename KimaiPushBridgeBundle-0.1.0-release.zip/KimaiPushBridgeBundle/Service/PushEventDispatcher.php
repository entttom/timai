<?php

declare(strict_types=1);

namespace KimaiPlugin\KimaiPushBridgeBundle\Service;

use App\Entity\User;
use Psr\Log\LoggerInterface;

final class PushEventDispatcher implements PushDispatcherInterface
{
    public function __construct(
        private readonly bool $enabled,
        private readonly ClientRequestInspector $clientRequestInspector,
        private readonly PushSubscriptionManager $pushSubscriptionManager,
        private readonly PushMessageBuilder $pushMessageBuilder,
        private readonly PushTopicResolver $pushTopicResolver,
        private readonly WebhookClient $webhookClient,
        private readonly LoggerInterface $logger
    ) {
    }

    public function dispatchToUser(User $recipient, string $eventName, array $payload, array $placeholderContext = [], array $logContext = []): void
    {
        if (!$this->enabled) {
            $this->logger->debug('Kimai push bridge is disabled', array_merge($logContext, [
                'event' => $eventName,
            ]));

            return;
        }

        if ($this->clientRequestInspector->isIosAppRequest()) {
            $this->logger->debug('Skipping push dispatch because request originated from Timai iOS', array_merge($logContext, [
                'event' => $eventName,
                'client' => ClientRequestInspector::CLIENT_IOS,
            ]));

            return;
        }

        $recipientId = $recipient->getId();
        if ($recipientId === null) {
            $this->logger->warning('Skipping push dispatch because recipient has no persisted identifier', array_merge($logContext, [
                'event' => $eventName,
            ]));

            return;
        }

        if (!$this->pushSubscriptionManager->isPushEnabled($recipient)) {
            $this->logger->debug('Skipping push dispatch because user has not enabled push bridge transport', array_merge($logContext, [
                'event' => $eventName,
                'user_id' => $recipientId,
            ]));

            return;
        }

        if (!$this->pushSubscriptionManager->isEventSubscribed($recipient, $eventName)) {
            $this->logger->debug('Skipping push dispatch because user disabled this push event', array_merge($logContext, [
                'event' => $eventName,
                'user_id' => $recipientId,
            ]));

            return;
        }

        try {
            $resolved = $this->pushTopicResolver->resolveForUserId($recipientId);
            $topic = $resolved['topic'];
            $message = $this->pushMessageBuilder->build($recipient, $eventName, $placeholderContext);
            $webhookPayload = array_merge([
                'event' => $eventName,
                'kimai_user_id' => $recipientId,
                'topic' => $topic,
                'language' => $message['language'],
                'visible_title' => $message['title'],
                'visible_body' => $message['body'],
            ], $payload);

            $this->webhookClient->send($eventName, $webhookPayload);

            $this->logger->info('Dispatched Kimai push bridge webhook', array_merge($logContext, [
                'event' => $eventName,
                'user_id' => $recipientId,
                'language' => $message['language'],
                'topic' => $topic,
                'normalized_instance' => $resolved['normalized_instance'],
            ]));
        } catch (\Throwable $error) {
            $this->logger->error('Failed to dispatch Kimai push bridge webhook', array_merge($logContext, [
                'event' => $eventName,
                'user_id' => $recipientId,
                'error' => $error->getMessage(),
                'error_class' => $error::class,
            ]));
        }
    }
}
