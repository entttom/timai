<?php

declare(strict_types=1);

namespace KimaiPlugin\KimaiPushBridgeBundle\EventSubscriber;

use KimaiPlugin\KimaiPushBridgeBundle\Service\WebhookQueue;
use Symfony\Component\Console\ConsoleEvents;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpKernel\KernelEvents;

final class WebhookQueueFlushSubscriber implements EventSubscriberInterface
{
    public function __construct(private readonly WebhookQueue $webhookQueue)
    {
    }

    public static function getSubscribedEvents(): array
    {
        return [
            KernelEvents::TERMINATE => 'flush',
            ConsoleEvents::TERMINATE => 'flush',
        ];
    }

    public function flush(): void
    {
        $this->webhookQueue->flush();
    }
}
