# Kimai Push Bridge Bundle

Dieses Bundle beobachtet relevante Kimai-Events und sendet einen signierten Webhook an einen Relay-Server. Der Relay verschickt daraus einen sichtbaren Push an ein FCM Topic. Der Data-Payload des Push enthaelt nur ein Sync-Signal mit IDs; die App holt den echten Zustand danach selbst ueber die Kimai-API.

**Hinweis zu den sichtbaren Push-Texten:** Die Standardtexte fuer Timer-Pushes enthalten Kunde, Projekt, Taetigkeit und Startzeit (z. B. „Timer gestartet für Musterkunde GmbH - Website Relaunch - Beratung um 08:30.“). Diese Texte werden ueber den Relay (Vercel), Firebase Cloud Messaging und Apple Push Notification Service zugestellt. Der Relay speichert und loggt die Texte nicht. Jeder User kann die Texte auf seiner Profilseite „Push Bridge“ anpassen, z. B. auf einen generischen Text ohne Platzhalter.

Die sichtbaren Push-Texte werden im Plugin in der beim Empfaenger eingestellten Kimai-Sprache erzeugt und als `visible_title` / `visible_body` an den Relay uebergeben. Fuer Sprachvarianten ohne eigene Plugin-Uebersetzung greift ein Fallback auf Englisch.

Wenn ein Event durch die Timai-iOS-App selbst ausgeloest wurde, unterdrueckt das Plugin den Push-Versand vollstaendig. Dafuer muss die App ihre schreibenden Kimai-API-Requests mit `X-Timai-Client: ios` markieren.

`normalized_instance` wird beim ersten Zugriff aus der Kimai-URL abgeleitet und danach fest unter `var/data/kimai_push_bridge/instance_name` gespeichert (oder per `instance_name` konfiguriert). Das Topic-Secret wird beim ersten Zugriff serverseitig erzeugt und unter `var/data/kimai_push_bridge/topic_secret` gespeichert. `var/data` muss deshalb persistent sein, sonst aendern sich die Topics nach jedem Neustart.

Ob ein User Push überhaupt erhalten soll, wird als User-Preference in Kimai gespeichert. Ohne aktives Opt-in der App wird kein Webhook für diesen User versendet.

## Installationspfad

Das Bundle gehört in die Kimai-Installation unter:

```text
var/plugins/KimaiPushBridgeBundle/
```

Wenn du dieses Repository direkt nutzt, kopiere den Ordner `var/plugins/KimaiPushBridgeBundle` in die Kimai-Instanz.

## Unterstützte Kimai-Events

- `App\Event\TimesheetCreatePostEvent`
- `App\Event\TimesheetRestartPostEvent`
- `App\Event\TimesheetStopPostEvent`
- `App\Event\WorkingTimeApproveMonthEvent`
- `App\Event\WorkingTimeUnlockMonthEvent`

Optional, wenn die jeweilige Kimai-Installation die Klassen bereitstellt:

- `App\Event\AbsenceRequestedEvent` oder `App\Event\AbsenceCreatedEvent`
- `App\Event\AbsenceApprovedEvent`
- `App\Event\AbsenceRejectedEvent`

## Konfiguration

Das Plugin funktioniert direkt nach dem Kopieren mit eingebauten Defaultwerten:

- `enabled: true`
- `relay_url: https://timai-push-plugin-kimai.vercel.app/api/webhooks/kimai`
- `webhook_secret: bxwlRDr7XChw4Ipbl7BLU2eFGcdnCSuaHAQ_Jl8aJ8k`
- `instance_name: ''` (leer = automatisch aus der ersten Request-URL ableiten und festschreiben)
- `request_timeout: 5`

Wenn du die Defaults überschreiben willst, kannst du optional `config/packages/local.yaml` ergänzen:

```yaml
kimai_push_bridge:
  relay_url: 'https://timai-push-plugin-kimai.vercel.app/api/webhooks/kimai'
  webhook_secret: 'bxwlRDr7XChw4Ipbl7BLU2eFGcdnCSuaHAQ_Jl8aJ8k'
  instance_name: 'time.example.com'
  request_timeout: 5
```

Alle Konfigurationswerte sind optional:

- `enabled` default `true`
- `relay_url` default eingebaut
- `webhook_secret` default eingebaut
- `instance_name` default leer
- `request_timeout` default `5.0`

## Topic-Modell

Das Topic wird lokal deterministisch erzeugt:

```text
kimai_<normalized_instance>_<user_hash>
```

- `normalized_instance` ist entweder das normalisierte `instance_name` aus der Konfiguration oder wird einmalig aus Hostname und Basis-Pfad des ersten Requests abgeleitet und unter `var/data/kimai_push_bridge/instance_name` festgeschrieben. Dadurch haengt das Topic nicht davon ab, ueber welchen Host (www, interne Adresse, Reverse Proxy) oder ob per CLI ein Event ausgeloest wurde. CLI-Befehle ohne festgeschriebenen Namen nutzen `framework.router.default_uri`, falls konfiguriert, sonst wird kein Push gesendet.
- Wer `instance_name` nachtraeglich setzt oder die Datei loescht, aendert die Topics aller User; die App erkennt das beim naechsten Abgleich ueber `GET /api/push-bridge/topic` und abonniert neu.
- `user_hash` ist `substr(hash_hmac('sha256', normalized_instance . ':' . user_id, topic_secret), 0, 16)`
- `topic_secret` wird serverseitig generiert und nie an die App ausgeliefert

## Topic-Endpoint für die App

Das Bundle stellt einen authentifizierten API-Endpoint bereit:

```text
GET /api/push-bridge/topic
```

Antwort:

```json
{
  "topic": "kimai_example_com_ab12cd34ef56abcd",
  "normalized_instance": "example_com",
  "kimai_user_id": 123,
  "push_enabled": false
}
```

Die iOS-App soll dieses Topic vom Server beziehen und abonnieren. Sie muss das Topic nicht selbst aus einem Secret berechnen.

## User-Preferences fuer Push-Abos

Der technische App-Subscribe bleibt ein globaler Transport-Schalter:

- `kimai_push_bridge_enabled`

Zusaetzlich kann jeder User in den Kimai-Preferences pro Push-Typ steuern, welche Pushes fachlich zugelassen sind:

- `kimai_push_bridge_event_timer`
- `kimai_push_bridge_event_absence_requested`
- `kimai_push_bridge_event_absence_approved`
- `kimai_push_bridge_event_absence_rejected`
- `kimai_push_bridge_event_working_time_approved`
- `kimai_push_bridge_event_working_time_unlocked`

Fehlende Event-Preferences werden serverseitig als `true` interpretiert, damit bestehende Nutzer nach dem Upgrade keine Pushes verlieren.

## Subscribe- und Unsubscribe-Endpoint

Nachdem die App das Topic erfolgreich bei FCM abonniert hat, soll sie Kimai serverseitig aktivieren:

```text
POST /api/push-bridge/subscribe
```

Der Request soll als JSON gesendet werden:

```http
Content-Type: application/json

{}
```

Antwort:

```json
{
  "ok": true,
  "push_enabled": true,
  "topic": "kimai_example_com_ab12cd34ef56abcd",
  "normalized_instance": "example_com",
  "kimai_user_id": 123
}
```

Beim Logout oder Opt-out soll die App die Aktivierung wieder zurücknehmen:

```text
POST /api/push-bridge/unsubscribe
```

Auch dieser Request soll als JSON mit Body `{}` gesendet werden.

Antwort:

```json
{
  "ok": true,
  "push_enabled": false,
  "kimai_user_id": 123
}
```

## Verhalten

- Ein neuer aktiver Timer löst `timer.started` aus
- Ein Restart löst `timer.started` aus (Kimai feuert dabei Create- und Restart-Event; beide werden zu einem Push zusammengefasst)
- Ein Stop löst `timer.stopped` aus
- Eine Monatsfreigabe löst `working_time.approved` aus
- Eine Monatsentsperrung löst `working_time.unlocked` aus
- Events werden nur dann an den Relay gesendet, wenn der User Push serverseitig aktiviert hat und das Event-Abo fuer diesen Push-Typ aktiv ist
- Die sichtbare Push-Nachricht wird pro Empfaenger in dessen Kimai-Sprache erzeugt
- Requests mit `X-Timai-Client: ios` erzeugen keinen Push, damit die iOS-App keine Echo-Benachrichtigungen fuer ihre eigenen Aktionen bekommt
- Historisch abgeschlossene neu erstellte Einträge werden ignoriert
- Webhooks werden waehrend des Requests nur gesammelt und erst bei `kernel.terminate` bzw. `console.terminate` gesendet, also nach dem Commit der Kimai-Transaktion und (unter PHP-FPM) nachdem die Antwort an den Browser ausgeliefert wurde. Der Relay-Aufruf verzoegert Start/Stopp im UI damit nicht mehr
- Vor dem Senden eines Timer-Push wird der gespeicherte Zustand des Timesheets geprueft. Wurde die Transaktion zurueckgerollt oder passt der Zustand nicht mehr zum Event, entfaellt der Push
- Mehrere Events mit gleichem `idempotency_key` im selben Request ergeben nur einen Push
- Sichtbare Texte werden nach dem Einsetzen der Platzhalter auf die Relay-Limits gekuerzt (Titel 120, Text 240 Zeichen, mit „…“), damit lange Kunden- oder Projektnamen den Push nicht verhindern
- Fehler beim Webhook-Dispatch werden nur geloggt und brechen Kimai nicht hart ab

## Installation in Kimai

1. Bundle in `var/plugins/KimaiPushBridgeBundle/` ablegen
2. Cache leeren:

```bash
bin/console cache:clear
```

3. Optional eine lokale Override-Konfiguration ergänzen
4. Optional prüfen, ob das Plugin erkannt wurde:

```bash
bin/console kimai:plugins
```

## Tests

Die Unit-Tests sind für Ausführung innerhalb einer Kimai-/PHPUnit-Umgebung gedacht:

```bash
php vendor/bin/phpunit var/plugins/KimaiPushBridgeBundle/Tests
```

## Lizenz

Dieses Plugin ist proprietär und wird unter "All Rights Reserved" bereitgestellt.

## Architekturhinweis für iOS

Der Push ist nur ein Sync-Signal. Die App darf beim Empfang oder beim Oeffnen der Mitteilung niemals blind lokal einen Timer starten oder stoppen. Sie soll das Topic über `GET /api/push-bridge/topic` beziehen, das Topic bei FCM abonnieren, danach `POST /api/push-bridge/subscribe` senden und UI oder Live Activity ausschließlich anhand des Serverzustands aktualisieren.
