<?php

declare(strict_types=1);

namespace KimaiPlugin\KimaiPushBridgeBundle\Service;

final class PluginStateStorage
{
    private const DIRECTORY = 'kimai_push_bridge';

    public function __construct(private readonly string $dataDir)
    {
    }

    public function read(string $name): ?string
    {
        $path = $this->getPath($name);

        if (!is_file($path)) {
            return null;
        }

        $value = trim((string) file_get_contents($path));

        return $value !== '' ? $value : null;
    }

    /**
     * Persists the value atomically. If the final rename fails because another process won the race,
     * the value that process stored is returned instead.
     */
    public function write(string $name, string $value): string
    {
        $path = $this->getPath($name);

        $directory = dirname($path);
        if (!is_dir($directory) && !@mkdir($directory, 0700, true) && !is_dir($directory)) {
            throw new \RuntimeException(sprintf('Unable to create push bridge state directory: %s', $directory));
        }

        $temporaryPath = $path . '.' . bin2hex(random_bytes(6)) . '.tmp';

        if (file_put_contents($temporaryPath, $value . PHP_EOL, LOCK_EX) === false) {
            throw new \RuntimeException(sprintf('Failed to persist push bridge state "%s".', $name));
        }

        @chmod($temporaryPath, 0600);

        if (!@rename($temporaryPath, $path)) {
            @unlink($temporaryPath);

            $existing = $this->read($name);
            if ($existing !== null) {
                return $existing;
            }

            throw new \RuntimeException(sprintf('Failed to finalize push bridge state "%s".', $name));
        }

        return $value;
    }

    private function getPath(string $name): string
    {
        return rtrim($this->dataDir, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . self::DIRECTORY . DIRECTORY_SEPARATOR . $name;
    }
}
