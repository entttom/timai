<?php

declare(strict_types=1);

namespace KimaiPlugin\KimaiPushBridgeBundle\Service;

use Symfony\Component\HttpFoundation\RequestStack;
use Symfony\Component\Routing\RequestContext;

/**
 * The instance name is part of every topic, so it must not depend on the host that triggered an event
 * (www vs. apex domain, internal hostnames, CLI commands). It is either configured explicitly or derived
 * once from the first request and pinned in the data directory.
 */
final class InstanceNameResolver
{
    private const STATE_KEY = 'instance_name';
    private const SYMFONY_DEFAULT_HOST = 'localhost';

    public function __construct(
        private readonly RequestStack $requestStack,
        private readonly RequestContext $requestContext,
        private readonly TopicNameGenerator $topicNameGenerator,
        private readonly PluginStateStorage $stateStorage,
        private readonly string $configuredInstanceName = ''
    ) {
    }

    public function resolveNormalizedInstanceName(): string
    {
        if (trim($this->configuredInstanceName) !== '') {
            $normalized = $this->topicNameGenerator->normalizeInstanceName($this->configuredInstanceName);
            if ($normalized === '') {
                throw new \LogicException('Configured kimai_push_bridge.instance_name does not contain any usable characters.');
            }

            return $normalized;
        }

        $stored = $this->stateStorage->read(self::STATE_KEY);
        if ($stored !== null) {
            $normalized = $this->topicNameGenerator->normalizeInstanceName($stored);
            if ($normalized !== '') {
                return $normalized;
            }
        }

        $normalized = $this->topicNameGenerator->normalizeInstanceName($this->deriveFromContext());
        if ($normalized === '') {
            throw new \RuntimeException('Unable to derive a valid Kimai instance name from the current request context.');
        }

        return $this->stateStorage->write(self::STATE_KEY, $normalized);
    }

    private function deriveFromContext(): string
    {
        $host = '';
        $basePath = '';
        $request = $this->requestStack->getMainRequest();

        if ($request !== null) {
            $host = $request->getHost();
            $basePath = $request->getBaseUrl();
        }

        // Without a request (CLI) the router context is only meaningful if default_uri was configured.
        if ($host === '' && $this->requestContext->getHost() !== self::SYMFONY_DEFAULT_HOST) {
            $host = $this->requestContext->getHost();
            $basePath = $this->requestContext->getBaseUrl();
        }

        $source = trim($host);
        $basePath = trim($basePath);

        if ($source === '') {
            throw new \RuntimeException('Unable to resolve the Kimai instance name yet. Configure kimai_push_bridge.instance_name or open Kimai once via its public URL.');
        }

        if ($basePath !== '' && $basePath !== '/') {
            $source .= $basePath;
        }

        return $source;
    }
}
