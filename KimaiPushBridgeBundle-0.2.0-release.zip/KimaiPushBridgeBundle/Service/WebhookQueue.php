<?php

declare(strict_types=1);

namespace KimaiPlugin\KimaiPushBridgeBundle\Service;

use Psr\Log\LoggerInterface;
use Symfony\Contracts\Service\ResetInterface;

/**
 * Collects webhooks during a request and sends them on kernel/console terminate, i.e. after Kimai
 * committed its transaction and (under PHP-FPM) after the response was delivered to the user.
 */
final class WebhookQueue implements ResetInterface
{
    /**
     * @var array<array-key, array{event: string, payload: array<string, mixed>, logContext: array<string, mixed>}>
     */
    private array $pending = [];

    public function __construct(
        private readonly WebhookClient $webhookClient,
        private readonly PushDeliveryGuardInterface $deliveryGuard,
        private readonly LoggerInterface $logger
    ) {
    }

    /**
     * @param array<string, mixed> $payload
     * @param array<string, mixed> $logContext
     */
    public function enqueue(string $eventName, array $payload, array $logContext = []): void
    {
        $entry = [
            'event' => $eventName,
            'payload' => $payload,
            'logContext' => $logContext,
        ];

        $idempotencyKey = (string) ($payload['idempotency_key'] ?? '');
        if ($idempotencyKey === '') {
            $this->pending[] = $entry;

            return;
        }

        // Kimai fires several events for one action (a restart dispatches both the create and the
        // restart post event), the idempotency key collapses them into a single push.
        if (isset($this->pending[$idempotencyKey])) {
            $this->logger->debug('Ignoring duplicate Kimai push bridge webhook', array_merge($logContext, [
                'event' => $eventName,
                'idempotency_key' => $idempotencyKey,
            ]));

            return;
        }

        $this->pending[$idempotencyKey] = $entry;
    }

    public function countPending(): int
    {
        return count($this->pending);
    }

    public function flush(): void
    {
        $pending = $this->pending;
        $this->pending = [];

        foreach ($pending as $entry) {
            $this->deliver($entry['event'], $entry['payload'], $entry['logContext']);
        }
    }

    public function reset(): void
    {
        $this->flush();
    }

    /**
     * @param array<string, mixed> $payload
     * @param array<string, mixed> $logContext
     */
    private function deliver(string $eventName, array $payload, array $logContext): void
    {
        try {
            if (!$this->deliveryGuard->isStillValid($eventName, $payload)) {
                $this->logger->info('Skipping Kimai push bridge webhook because the persisted state no longer matches the event', array_merge($logContext, [
                    'event' => $eventName,
                ]));

                return;
            }

            $this->webhookClient->send($eventName, $payload);

            $this->logger->info('Dispatched Kimai push bridge webhook', array_merge($logContext, [
                'event' => $eventName,
            ]));
        } catch (\Throwable $error) {
            $this->logger->error('Failed to dispatch Kimai push bridge webhook', array_merge($logContext, [
                'event' => $eventName,
                'error' => $error->getMessage(),
                'error_class' => $error::class,
            ]));
        }
    }
}
