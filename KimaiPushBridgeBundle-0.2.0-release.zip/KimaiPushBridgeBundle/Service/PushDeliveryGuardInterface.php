<?php

declare(strict_types=1);

namespace KimaiPlugin\KimaiPushBridgeBundle\Service;

interface PushDeliveryGuardInterface
{
    /**
     * Called right before a queued webhook is sent, after Kimai committed (or rolled back) its changes.
     *
     * @param array<string, mixed> $payload
     */
    public function isStillValid(string $eventName, array $payload): bool;
}
