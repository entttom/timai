<?php

declare(strict_types=1);

namespace KimaiPlugin\KimaiPushBridgeBundle\Service;

use App\Repository\TimesheetRepository;
use Doctrine\ORM\AbstractQuery;

/**
 * Kimai dispatches TimesheetCreatePostEvent inside a transaction that can still be rolled back
 * (e.g. when stopping the previous timer fails). Timer pushes are therefore only sent if the
 * committed database state still matches the event.
 */
final class TimesheetStateGuard implements PushDeliveryGuardInterface
{
    public function __construct(private readonly TimesheetRepository $timesheetRepository)
    {
    }

    public function isStillValid(string $eventName, array $payload): bool
    {
        if ($eventName !== PushEvents::TIMER_STARTED && $eventName !== PushEvents::TIMER_STOPPED) {
            return true;
        }

        $timesheetId = $payload['timesheet_id'] ?? null;
        if (!is_int($timesheetId)) {
            return false;
        }

        // Scalar result on purpose: the identity map may still hold entities of a rolled back transaction.
        $row = $this->timesheetRepository->createQueryBuilder('t')
            ->select('t.end AS endTime')
            ->where('t.id = :id')
            ->setParameter('id', $timesheetId)
            ->getQuery()
            ->getOneOrNullResult(AbstractQuery::HYDRATE_SCALAR);

        if (!is_array($row)) {
            return false;
        }

        $isRunning = $row['endTime'] === null;

        return $eventName === PushEvents::TIMER_STARTED ? $isRunning : !$isRunning;
    }
}
