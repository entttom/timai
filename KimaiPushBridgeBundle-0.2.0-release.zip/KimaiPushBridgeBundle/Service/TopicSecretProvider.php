<?php

declare(strict_types=1);

namespace KimaiPlugin\KimaiPushBridgeBundle\Service;

use Psr\Log\LoggerInterface;

final class TopicSecretProvider
{
    private const STATE_KEY = 'topic_secret';

    public function __construct(
        private readonly PluginStateStorage $stateStorage,
        private readonly LoggerInterface $logger
    ) {
    }

    public function getSecret(): string
    {
        $secret = $this->stateStorage->read(self::STATE_KEY);
        if ($secret !== null) {
            return $secret;
        }

        $secret = $this->stateStorage->write(self::STATE_KEY, bin2hex(random_bytes(32)));

        $this->logger->info('Generated Kimai Push Bridge topic secret');

        return $secret;
    }
}
