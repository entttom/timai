<?php

declare(strict_types=1);

namespace KimaiPlugin\KimaiPushBridgeBundle\Controller\Api;

use App\API\BaseApiController;
use App\Repository\UserRepository;
use KimaiPlugin\KimaiPushBridgeBundle\Service\PushSubscriptionManager;
use KimaiPlugin\KimaiPushBridgeBundle\Service\PushTopicResolver;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Routing\Attribute\Route;
use Symfony\Component\Security\Http\Attribute\IsGranted;

#[IsGranted('API')]
#[Route(path: '/push-bridge')]
final class PushTopicController extends BaseApiController
{
    #[Route(path: '/topic', methods: ['GET'])]
    public function topicAction(
        PushTopicResolver $pushTopicResolver,
        PushSubscriptionManager $pushSubscriptionManager,
        UserRepository $userRepository
    ): JsonResponse {
        $user = $this->getUser();
        if ($pushSubscriptionManager->ensureEventPreferences($user)) {
            $userRepository->saveUser($user);
        }

        $resolved = $pushTopicResolver->resolveForUserId($user->getId());

        return $this->json([
            'topic' => $resolved['topic'],
            'normalized_instance' => $resolved['normalized_instance'],
            'kimai_user_id' => $user->getId(),
            'push_enabled' => $pushSubscriptionManager->isPushEnabled($user),
        ]);
    }

    #[Route(path: '/subscribe', methods: ['POST'])]
    public function subscribeAction(
        PushTopicResolver $pushTopicResolver,
        PushSubscriptionManager $pushSubscriptionManager,
        UserRepository $userRepository
    ): JsonResponse {
        $user = $this->getUser();
        $pushSubscriptionManager->subscribe($user);
        $userRepository->saveUser($user);

        $resolved = $pushTopicResolver->resolveForUserId($user->getId());

        return $this->json([
            'ok' => true,
            'push_enabled' => true,
            'topic' => $resolved['topic'],
            'normalized_instance' => $resolved['normalized_instance'],
            'kimai_user_id' => $user->getId(),
        ]);
    }

    #[Route(path: '/unsubscribe', methods: ['POST'])]
    public function unsubscribeAction(
        PushSubscriptionManager $pushSubscriptionManager,
        UserRepository $userRepository
    ): JsonResponse {
        $user = $this->getUser();
        $pushSubscriptionManager->unsubscribe($user);
        $userRepository->saveUser($user);

        return $this->json([
            'ok' => true,
            'push_enabled' => false,
            'kimai_user_id' => $user->getId(),
        ]);
    }
}
